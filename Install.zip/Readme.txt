1) Unzip anywhere.

2) Run DuckSetup.exe.

3) Restart computer.